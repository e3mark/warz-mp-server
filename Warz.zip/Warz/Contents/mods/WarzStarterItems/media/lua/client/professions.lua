return {"p_slacker", "p_carpenter", "p_metalworker", "p_mechanic", "p_engineer", "p_tailor", "p_nomad", "p_trapper", "p_fisherman", "p_farmer", "p_infiltrator", "p_survivor", "p_fighter" , "p_cook"}
